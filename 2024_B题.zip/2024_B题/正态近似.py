import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import binom, norm

# Define parameters for binomial distribution
p = 10  # probability of success
n_values = [30, 50, 100, 500]  # increasing values of n

# Generate the plots for different values of n
x_values = np.arange(-0.5, 100.5, 0.1)  # x values for normal approximation

# Adjust standard deviation by altering p value to make the graphs less steep
p_adjusted = 0.3  # Changing p to make the variance larger

# Create a new figure for plotting
fig, axes = plt.subplots(2, 2, figsize=(12, 10))
axes = axes.flatten()

# Generate the plots for different values of n with adjusted p
for i, n in enumerate(n_values):
    x = np.arange(0, n + 1)
    binom_pmf = binom.pmf(x, n, p_adjusted)
    
    # Normal approximation: mean and standard deviation with adjusted p
    mean = n * p_adjusted
    std = np.sqrt(n * p_adjusted * (1 - p_adjusted))
    normal_approx = norm.pdf(x_values, mean, std)
    
    # Plot both distributions
    axes[i].bar(x, binom_pmf, width=0.8, label=f'Binomial PMF (n={n})', color='blue', alpha=0.6)
    axes[i].plot(x_values, normal_approx, label='Normal Approximation', color='red')
    
    axes[i].set_title(f'Binomial vs Normal Approximation (n={n}, p={p_adjusted})')
    axes[i].set_xlabel('x')
    axes[i].set_ylabel('Probability')
    axes[i].legend()

plt.tight_layout()
plt.show()
