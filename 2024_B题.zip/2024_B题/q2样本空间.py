# 导入所需的包
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from matplotlib.font_manager import FontProperties

# 创建2x2的表格
table_data = [
    ['p0 * p1', 'p0 * (1 - p1)'],
    ['(1 - p0) * p1', '(1 - p0) * (1 - p1)']
]

# 构建一个用于着色的矩阵，右下角为1（代表绿色），其余为0（代表蓝色）
heatmap_colors = np.array([[0, 0], [0, 1]])

# 设置画布大小
plt.figure(figsize=(8, 6))

# 使用Seaborn的heatmap来显示表格
sns.heatmap(heatmap_colors, annot=table_data, fmt='', cbar=False, cmap='Blues', linewidths=1, linecolor='black',
            annot_kws={"size": 16}, square=True)

# 右下角方格用绿色填充
sns.heatmap(heatmap_colors, annot=table_data, fmt='', cbar=False, cmap=sns.color_palette("crest", as_cmap=True), 
            mask=(heatmap_colors != 1), linewidths=1, linecolor='black', annot_kws={"size": 16}, square=True)

# 设置x轴和y轴标签
plt.xticks([0.5, 1.5], ['p1', '1 - p1'], fontsize=14)
plt.yticks([0.5, 1.5], ['p0', '1 - p0'], fontsize=14, rotation=0)

# 设置标题，确保字体文件路径正确
myfont = FontProperties(fname='./SimHei.ttf')
plt.title(r'样本空间概率', fontsize=18, fontproperties=myfont)

# 显示图形
plt.show()
