import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np

# 设置中文字体
font_path = '/Users/panlongxiang/Documents/数模/2024_B题/SimHei.ttf'  # 请确保在相同目录下有 SimHei.ttf 字体文件
my_font = font_manager.FontProperties(fname=font_path)

# 决策组合
decisions = [
    '0000', '0001', '0010', '0011', '0100', '0101', '0110', '0111',
    '1000', '1001', '1010', '1011', '1100', '1101', '1110', '1111'
]

# 成本和利润数据按情形排列
results = {
    0: {'costs': [29.63, 27.22, 31.00, 28.59, 33.94, 31.11, 35.80, 32.97, 31.54, 30.11, 33.40, 31.97, 35.80, 34.10, 38.20, 36.50],
        'profits': [11.20, 13.61, 9.82, 12.23, 11.42, 14.25, 9.56, 12.39, 13.82, 15.25, 11.96, 13.39, 14.60, 16.30, 12.20, 13.90]},
    1: {'costs': [30.93, 27.03, 31.00, 27.10, 36.76, 31.44, 37.60, 32.28, 32.96, 30.44, 33.80, 31.28, 38.60, 35.20, 40.40, 37.00],
        'profits': [-2.26, 1.64, -2.33, 1.57, -0.92, 4.40, -1.76, 3.56, 2.88, 5.40, 2.04, 4.56, 6.20, 9.60, 4.40, 7.80]},
    2: {'costs': [36.13, 33.72, 31.00, 28.59, 38.50, 35.67, 35.80, 32.97, 36.10, 34.67, 33.40, 31.97, 38.20, 36.50, 38.20, 36.50],
        'profits': [4.69, 7.10, 9.82, 12.23, 6.86, 9.69, 9.56, 12.39, 9.26, 10.69, 11.96, 13.39, 12.20, 13.90, 12.20, 13.90]},
    3: {'costs': [42.64, 38.74, 30.00, 26.10, 43.40, 38.08, 34.60, 29.28, 40.60, 38.08, 31.80, 29.28, 40.40, 37.00, 36.40, 33.00],
        'profits': [-13.97, -10.07, -1.33, 2.57, -7.56, -2.24, 1.24, 6.56, -4.76, -2.24, 4.04, 6.56, 4.40, 7.80, 8.40, 11.80]},
    4: {'costs': [31.52, 29.54, 30.00, 28.02, 34.50, 31.67, 34.60, 31.77, 39.20, 38.04, 38.40, 37.24, 42.00, 40.30, 43.00, 41.30],
        'profits': [4.77, 6.75, 6.29, 8.27, 10.86, 13.69, 10.76, 13.59, 1.12, 2.28, 1.92, 3.08, 8.40, 10.10, 7.40, 9.10]},
    5: {'costs': [29.43, 33.09, 31.00, 34.67, 32.88, 34.83, 34.90, 36.85, 31.18, 33.83, 33.20, 35.86, 34.60, 35.50, 37.10, 38.00],
        'profits': [18.59, 14.92, 17.01, 13.35, 17.66, 15.71, 15.64, 13.69, 19.36, 16.71, 17.34, 14.68, 18.60, 17.70, 16.10, 15.20]}
}

# 创建图表
for case in range(6):
    plt.figure(figsize=(12, 6))
    
    # 绘制柱状图，利润为蓝色，成本为绿色
    bar_width = 0.35
    index = np.arange(len(decisions))
    
    # 绘制所有决策的利润和成本
    plt.bar(index, results[case]['profits'], bar_width, color='lime', label='利润')
    plt.bar(index + bar_width, results[case]['costs'], bar_width, color='aqua', label='成本')
    
    # 找到利润最高的决策
    max_profit = max(results[case]['profits'])
    max_profit_index = results[case]['profits'].index(max_profit)
    max_profit_decision = decisions[max_profit_index]
    
    # 标注利润最高的决策
    plt.axhline(y=max_profit, color='red', linestyle='--', label=f'最大利润: {max_profit}')
    plt.text(max_profit_index, max_profit + 1, f'{max_profit_decision}', ha='center', va='bottom', color='red', fontproperties=my_font)

    # 突出显示利润最高决策的柱子
    plt.bar(max_profit_index, max_profit, bar_width, color='darkgreen')
    
    # 图表信息
    plt.title(f'情形 {case + 1} 成本与利润的比较', fontproperties=my_font)
    plt.xlabel('决策 (xp1, xp2, xf, xd)', fontproperties=my_font)
    plt.ylabel('金额', fontproperties=my_font)
    plt.xticks(index + bar_width / 2, decisions, rotation=45, fontproperties=my_font)
    plt.legend(prop=my_font)
    plt.tight_layout()
    
    # 保存图像
    plt.savefig(f'./情形{case + 1}穷举图.png')

# 显示图像
plt.show()
