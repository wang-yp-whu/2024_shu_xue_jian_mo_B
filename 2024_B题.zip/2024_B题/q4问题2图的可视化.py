import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# 设置中文字体路径
font = FontProperties(fname='/Users/panlongxiang/Documents/数模/2024_B题/SimHei.ttf')

# 数据
circumstances = ['情形 1', '情形 2', '情形 3', '情形 4', '情形 5', '情形 6']
decision_labels = ['零件1', '零件2', '成品', '拆解']

# 零部件1变化的数据
data_parts1 = np.array([
    [372, 400, 0, 400],
    [400, 400, 0, 400],
    [346, 400, 54, 400],
    [400, 400, 400, 400],
    [0, 400, 162, 400],
    [261, 0, 0, 0]
])

# 零部件2变化的数据
data_parts2 = np.array([
    [400, 288, 0, 400],
    [400, 400, 0, 400],
    [400, 249, 151, 400],
    [400, 400, 400, 400],
    [0, 400, 0, 400],
    [400, 126, 0, 0]
])

# 成品次品率变化的数据
data_final_product = np.array([
    [400, 400, 0, 400],
    [400, 400, 0, 400],
    [400, 400, 200, 400],
    [400, 400, 400, 400],
    [0, 400, 162, 400],
    [400, 0, 0, 0]
])

# 定义绘制函数
def plot_decision_ratios(data, title):
    fig, ax = plt.subplots(figsize=(10, 6))
    
    # 计算百分比
    ratio_data = data / 400
    
    # 绘制每个决策变量的柱状图
    bar_width = 0.15
    for i, label in enumerate(decision_labels):
        ax.bar(np.arange(len(circumstances)) + i * bar_width, ratio_data[:, i], width=bar_width, label=label)
    
    ax.set_xlabel('情形', fontproperties=font)
    ax.set_ylabel('决策取“1”的占比', fontproperties=font)
    ax.set_title(title, fontproperties=font)
    ax.set_xticks(np.arange(len(circumstances)) + bar_width * (len(decision_labels) / 2))
    ax.set_xticklabels(circumstances, fontproperties=font, rotation=45)
    ax.legend(prop=font)

    plt.tight_layout()
    plt.savefig(f"问题4-2部件{str(data)}的变化决策位占比图.png")
    plt.show()

# 绘制零部件1变化的柱状图
plot_decision_ratios(data_parts1, '决策占比 - 零部件1变化')

# 绘制零部件2变化的柱状图
plot_decision_ratios(data_parts2, '决策占比 - 零部件2变化')

# 绘制成品次品率变化的柱状图
plot_decision_ratios(data_final_product, '决策占比 - 成品次品率变化')
