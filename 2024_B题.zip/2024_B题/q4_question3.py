import numpy as np
import random
import math

# 定义参数
confidence_interval = (0.08837, 0.11163) #抽样概率的置信区间
# 定义参数
confidence_interval = (0.08837, 0.11163)  # 抽样概率的置信区间
P_parts_defect = [0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1]  # 各零件初始次品率

# 购买成本和检测成本
C_parts = [2, 8, 12, 2, 8, 12, 8, 12]  # 零件成本
D_parts = [1, 1, 2, 1, 1, 2, 1, 2]    # 零件检测成本

# 半成品的装配成本、检测成本和拆解费用
C_half = [8, 8, 8]  # 半成品装配成本
D_half = [4, 4, 4]  # 半成品检测成本
D_disassemble_half = [6, 6, 6]  # 半成品拆解费用

# 成品的装配成本、检测成本、市场售价、调换损失、拆解费用
C_assemble = 8       # 成品装配成本
D_final = 6          # 成品检测成本
Market_price = 200   # 市场售价
L_replace = 40       # 调换损失
D_disassemble_final = 10  # 成品拆解费用

# 拆解收益函数1（用于处理三个零件的拆解：半成品1和2）
def calculate_disassemble_profit_three(xp1, xp2, xp3, p1, p2, p3, final_defect, C_parts1, C_parts2, C_parts3, P_final_defect):
    # 判断 final_defect 是否为 0，若为 0 则将其设为 1，避免除零错误
    if final_defect == 0:
        final_defect = 1

    dis_profit = 0
    # 计算零件1的拆解收益
    if xp1:  # 零件1检测过，直接拆解
        dis_profit += C_parts1
    else:  # 未检测，使用条件概率计算拆解收益
        dis_profit += (1 - p1) * (p2 + p3 - p2 * p3 + (1 - p2) * (1 - p3) * 0.1) / final_defect * C_parts1

    # 计算零件2的拆解收益
    if xp2:  # 零件2检测过，直接拆解
        dis_profit += C_parts2
    else:  # 未检测，使用条件概率计算拆解收益
        dis_profit += (1 - p2) * (p1 + p3 - p1 * p3 + (1 - p1) * (1 - p3) * 0.1) / final_defect * C_parts2

    # 计算零件3的拆解收益
    if xp3:  # 零件3检测过，直接拆解
        dis_profit += C_parts3
    else:  # 未检测，使用条件概率计算拆解收益
        dis_profit += (1 - p3) * (p1 + p2 - p1 * p2 + (1 - p1) * (1 - p2) * 0.1) / final_defect * C_parts3

    return dis_profit

def calculate_disassemble_profit_two(xp1, xp2, p1, p2, final_defect, C_parts1, C_parts2, P_final_defect):
    # 判断 final_defect 是否为 0，若为 0 则将其设为 1，避免除零错误
    if final_defect == 0:
        final_defect = 1

    dis_profit = 0
    # 计算零件1的拆解收益
    if xp1:  # 零件1检测过，直接拆解
        dis_profit += C_parts1
    else:  # 未检测，使用条件概率计算拆解收益
        dis_profit += (1 - p1) * p2 / final_defect * C_parts1

    # 计算零件2的拆解收益
    if xp2:  # 零件2检测过，直接拆解
        dis_profit += C_parts2
    else:  # 未检测，使用条件概率计算拆解收益
        dis_profit += (1 - p2) * p1 / final_defect * C_parts2

    return dis_profit

# 计算成品的拆解收益，将成品视为由三个半成品组成
def calculate_final_disassemble_profit(xh1, xh2, xh3, p1, p2, p3, final_defect, C_half1, C_half2, C_half3, P_final_defect):
    # 计算成品的拆解收益，使用半成品的成本（包括零件成本和装配成本）及次品率
    return calculate_disassemble_profit_three(xh1, xh2, xh3, p1, p2, p3, final_defect, C_half1, C_half2, C_half3, P_final_defect)

# 成本和利润计算函数
def calculate_cost_and_profit(solution):
    # 解的结构: 零件检测 (8个独立决策, 分别对应1，2，3，4，5，6, 7, 8)，半成品检测+拆解 (半成品1，2,3)，成品检测+拆解
    xp = solution[:8]  # 零件检测决策 (1=4, 2=5, 3=6, 7, 8)
    xh_detect = solution[8:11]  # 半成品检测决策 (1个同步决策控制半成品1=2, 半成品3)
    xh_disassemble = solution[11:14]  # 半成品拆解决策 (1个同步决策控制半成品1=2, 半成品3)
    xf_detect = solution[14]    # 成品检测决策
    xf_disassemble = solution[15]  # 成品拆解决策

    # 零件次品率处理：如果检测了，次品率设为0；否则保持原有次品率
    p_parts_defect_1 = 0 if xp[0] == 1 else P_parts_defect[0]  # 零件1
    p_parts_defect_4 = 0 if xp[1] == 1 else P_parts_defect[1]  # 零件4（同步决策）
    p_parts_defect_2 = 0 if xp[2] == 1 else P_parts_defect[2]  # 零件2
    p_parts_defect_5 = 0 if xp[3] == 1 else P_parts_defect[3]  # 零件5（同步决策）
    p_parts_defect_3 = 0 if xp[4] == 1 else P_parts_defect[4]  # 零件3
    p_parts_defect_6 = 0 if xp[5] == 1 else P_parts_defect[5] # 零件6（同步决策）
    p_parts_defect_7 = 0 if xp[6] == 1 else P_parts_defect[6] # 零件7（独立）
    p_parts_defect_8 = 0 if xp[7] == 1 else P_parts_defect[7] # 零件8（独立）

    # 半成品次品率处理：半成品1和2的决策相同
    p_half_defect_1 = (1 - (1 - p_parts_defect_1) * (1 - p_parts_defect_2) * (1 - p_parts_defect_3)) + \
                      (1 - p_parts_defect_1) * (1 - p_parts_defect_2) * (1 - p_parts_defect_3) * P_parts_defect[8]

    p_half_defect_2 = (1 - (1 - p_parts_defect_4) * (1 - p_parts_defect_5) * (1 - p_parts_defect_6)) + \
                      (1 - p_parts_defect_4) * (1 - p_parts_defect_5) * (1 - p_parts_defect_6) * P_parts_defect[9]

    p_half_defect_3 = (1 - (1 - p_parts_defect_7) * (1 - p_parts_defect_8)) + \
                      (1 - p_parts_defect_7) * (1 - p_parts_defect_8) * P_parts_defect[10]

    # 根据检测决策更新半成品次品率
    p_half_defect_1 = 0 if xh_detect[0] == 1 else p_half_defect_1
    p_half_defect_2 = 0 if xh_detect[1] == 1 else p_half_defect_2
    p_half_defect_3 = 0 if xh_detect[2] == 1 else p_half_defect_3

    # 成品次品率处理：如果检测了，次品率设为0；否则根据半成品次品率计算
    p_final_defect = (1 - (1 - p_half_defect_1) * (1 - p_half_defect_2) * (1 - p_half_defect_3)) + \
                    (1 - p_half_defect_1) * (1 - p_half_defect_2) * (1 - p_half_defect_3) * P_parts_defect[11]

    # 计算零件的购买和检测成本
    cost_parts = (C_parts[0] + xp[0] * D_parts[0] + xp[0] * C_parts[0] * P_parts_defect[0]) + \
                 (C_parts[1] + xp[1] * D_parts[1] + xp[1] * C_parts[1] * P_parts_defect[1]) + \
                 (C_parts[2] + xp[2] * D_parts[2] + xp[2] * C_parts[2] * P_parts_defect[2]) + \
                 (C_parts[3] + xp[3] * D_parts[3] + xp[3] * C_parts[3] * P_parts_defect[3]) + \
                 (C_parts[4] + xp[4] * D_parts[4] + xp[4] * C_parts[4] * P_parts_defect[4]) + \
                 (C_parts[5] + xp[5] * D_parts[5] + xp[5] * C_parts[5] * P_parts_defect[5]) + \
                 (C_parts[6] + xp[6] * D_parts[6] + xp[6] * C_parts[6] * P_parts_defect[6]) + \
                 (C_parts[7] + xp[7] * D_parts[7] + xp[7] * C_parts[7] * P_parts_defect[7])


    # 计算拆解收益（半成品1=2使用三个零件，半成品3使用两个零件）
    dis_profit_three_1 = calculate_disassemble_profit_three(xp[0], xp[1], xp[2], p_parts_defect_1, p_parts_defect_2, p_parts_defect_3, p_half_defect_1, C_parts[0], C_parts[1], C_parts[2], P_parts_defect[11])
    dis_profit_three_2 = calculate_disassemble_profit_three(xp[3], xp[4], xp[5], p_parts_defect_3, p_parts_defect_4, p_parts_defect_5, p_half_defect_2, C_parts[3], C_parts[4], C_parts[5], P_parts_defect[11])
    dis_profit_two = calculate_disassemble_profit_two(xp[6], xp[7], p_parts_defect_6, p_parts_defect_7, p_half_defect_3, C_parts[6], C_parts[7], P_parts_defect[11])

    # 半成品的装配、检测和（拆解成本-拆解收益）
    cost_half = sum(
        [C_half[0] + xh_detect[0] * D_half[0] + (xh_disassemble[0] * D_disassemble_half[0] - dis_profit_three_1) * p_half_defect_1,  # 半成品1=2
         C_half[1] + xh_detect[1] * D_half[1] +(xh_disassemble[1] * D_disassemble_half[1] - dis_profit_three_2) * p_half_defect_2,  # 半成品2
         C_half[2] + xh_detect[2] * D_half[2] + (xh_disassemble[2] * D_disassemble_half[2] - dis_profit_two) * p_half_defect_3])  # 半成品3

    # 计算成品的拆解收益
    final_disassemble_profit = calculate_final_disassemble_profit(xh_detect[0], xh_detect[1], xh_detect[2], p_half_defect_1, p_half_defect_2, p_half_defect_3, p_final_defect, C_half[0], C_half[1], C_half[2], P_parts_defect[11])

    # 判断成品是否拆
    if xf_disassemble:
        cost_disassemble_final = (D_disassemble_final - final_disassemble_profit) * p_final_defect
    else:
        cost_disassemble_final = 0

    # 成品的装配、检测和拆解成本
    cost_assemble = C_assemble + xf_detect * D_final
    cost_replace = 0 if xf_detect == 1 else L_replace * p_final_defect  # 调换损失

    # 计算总成本
    total_cost = cost_parts + cost_half + cost_assemble + cost_replace + cost_disassemble_final
    # 计算售价
    total_income = Market_price * (1 - p_final_defect)

    profit = total_income - total_cost
    return total_cost, profit


# 模拟退火算法实现
def simulated_annealing():
    # 初始化解（随机决策，16个决策变量: 8个零件检测决策, 半成品1检测+拆解决策, 半成品2检测+拆解决策，半成品3检测+拆解决策, 成品检测+拆解决策）
    current_solution = np.random.randint(2, size=16)  # 初始化包含零件、半成品和成品的决策
    best_solution = current_solution.copy()
    best_profit = calculate_cost_and_profit(current_solution)[1]
    best_cost = calculate_cost_and_profit(current_solution)[0]
    T = 1000  # 初始温度
    T_min = 1  # 最低温度
    alpha = 0.9  # 降温系数

    while T > T_min:
        for _ in range(100):
            # 生成邻域解（随机改变一个决策变量）
            new_solution = current_solution.copy()
            idx = random.randint(0, 15)  # 随机改变1个决策变量
            new_solution[idx] = 1 - new_solution[idx]  # 改变该决策变量

            # 计算新解的利润
            new_cost, new_profit = calculate_cost_and_profit(new_solution)

            # 接受新解的概率
            if new_profit > best_profit or random.random() < math.exp((new_profit - best_profit) / T):
                current_solution = new_solution.copy()
                if new_profit > best_profit:
                    best_solution = new_solution.copy()
                    best_profit = new_profit
                    best_cost = new_cost

        T *= alpha  # 降低温度

    return best_solution, best_profit, best_cost


# 函数：将决策转换为文字说明
def get_decision_description(solution):
    part_desc = [
        f"零件1检测: {'是' if solution[0] == 1 else '否'}",
        f"零件2检测: {'是' if solution[1] == 1 else '否'}",
        f"零件3检测: {'是' if solution[2] == 1 else '否'}",
        f"零件4检测: {'是' if solution[3] == 1 else '否'}",
        f"零件5检测: {'是' if solution[4] == 1 else '否'}",
        f"零件6检测: {'是' if solution[5] == 1 else '否'}",
        f"零件7检测: {'是' if solution[6] == 1 else '否'}",
        f"零件8检测: {'是' if solution[7] == 1 else '否'}"
    ]
    half_part_desc = [
        f"半成品1检测: {'是' if solution[8] == 1 else '否'}",
        f"半成品2检测: {'是' if solution[10] == 1 else '否'}",
        f"半成品3检测: {'是' if solution[12] == 1 else '否'}",
        f"半成品1拆解: {'是' if solution[9] == 1 else '否'}",
        f"半成品2拆解: {'是' if solution[11] == 1 else '否'}",
        f"半成品3拆解: {'是' if solution[13] == 1 else '否'}",
        f"成品检测: {'是' if solution[14] == 1 else '否'}",
        f"成品拆解: {'是' if solution[15] == 1 else '否'}"
    ]
    return part_desc + half_part_desc

# 函数：枚举当前部件的次品率，并保持其他部件的次品率不变
def explore_defect_rate_for_part(part_index, confidence_interval, resolution=0.0001):
    """
    对某个部件的次品率进行枚举，固定其他部件次品率，调用模拟退火算法寻找最优决策。
    :param part_index: 当前部件的索引。
    :param confidence_interval: 当前部件次品率的置信区间。
    :param resolution: 次品率变化步长，默认为万分位。
    """
    lower_bound, upper_bound = confidence_interval
    defect_rates = np.arange(lower_bound, upper_bound + resolution, resolution)
    
    # 保存每个次品率下的最优决策结果
    decision_results = []
    global P_parts_defect
    # 遍历次品率
    for defect_rate in defect_rates:
        # 设置当前部件的次品率
        P_parts_defect[part_index] = defect_rate
        
        # 运行模拟退火算法，计算最优解
        best_solution, best_profit, best_cost = simulated_annealing()
        
        # 保存结果
        decision_results.append({
            'defect_rate': defect_rate,
            'best_solution': best_solution,
            'best_profit': best_profit,
            'best_cost': best_cost
        })
        
        # 以16位二进制格式输出最佳方案
        binary_solution = ''.join(map(str, best_solution))
        decision_desc = get_decision_description(best_solution)
    
    return decision_results

# 函数：按决策方案对结果排序
def sort_by_decision(decision_results):
    """
    按决策方案排序，统计出现频率最多的决策组合。
    :param decision_results: 决策结果列表。
    """
    decision_counts = {}
    
    for result in decision_results:
        decision_tuple = tuple(result['best_solution'])
        if decision_tuple in decision_counts:
            decision_counts[decision_tuple] += 1
        else:
            decision_counts[decision_tuple] = 1
    
    # 按频率排序
    sorted_decisions = sorted(decision_counts.items(), key=lambda x: x[1], reverse=True)
    
    return sorted_decisions

# 主函数：依次对每个部件次品率进行探索
for part_idx in range(12):
    print(f"\n==== 探索部件 {part_idx + 1} 的次品率 ====")
    part_results = explore_defect_rate_for_part(part_idx, confidence_interval)
    
    # 对决策方案进行排序
    sorted_decisions = sort_by_decision(part_results)
    
    print(f"\n部件 {part_idx + 1} 的次品率下，不同决策方案的出现频率排序：")
    for decision, count in sorted_decisions:
        # 将决策以16位二进制数显示
        binary_decision = ''.join(map(str, decision))
        print(f"决策 {binary_decision} 出现次数: {count}")