import numpy as np
import csv

# 定义零件1的次品率的95%置信区间
confidence_intervals_parts1 = [
    (0.08837,0.11163),  # 对应10%次品率
    (0.18837, 0.21163),  # 对应20%次品率
    (0.08837,0.11163),  # 对应10%次品率
    (0.18837, 0.21163),  # 对应20%次品率
    (0.08837,0.11163),  # 对应10%次品率
    (0.03837, 0.06163)   # 对应5%次品率
]
# 定义参数
P_parts_defect2 = [0.1, 0.2, 0.1, 0.2, 0.2, 0.05]  # 零配件2的次品率（不变）
P_final_defect = [0.1, 0.2, 0.1, 0.2, 0.1, 0.05]  # 成品的次品率
C_parts1 = 4  # 零配件1的购买成本
C_parts2 = 18  # 零配件2的购买成本
D_parts1 = [2, 2, 2, 1, 8, 2]  # 零配件1的检测成本
D_parts2 = [3, 3, 3, 1, 1, 3]  # 零配件2的检测成本
C_assemble = 6  # 装配成本
D_final = [3, 3, 3, 2, 2, 3]  # 成品的检测成本
Market_price = 56  # 市场售价
L_replace = [6, 6, 30, 30, 10, 10]  # 调换损失
D_disassemble = [5, 5, 5, 5, 5, 40]  # 拆解费用


# 成本和利润计算函数，包含成品拆解决策
def calculate_cost_and_profit(solution, i, P_parts_defect1):
    xp1, xp2, xf, xd = solution  # 包含拆解决策（xd）
    global disassemble_profit
    # 零配件购买成本始终存在，无论是否销售
    cost_parts = C_parts1 + C_parts2

    # 如果对零配件1进行检测，加入检测成本
    if xp1 == 1:
        cost_parts += D_parts1[i] + C_parts1 * P_parts_defect1
        p1 = 0  # 检测后无次品
    else:
        p1 = P_parts_defect1

    # 如果对零配件2进行检测，加入检测成本
    if xp2 == 1:
        cost_parts += D_parts2[i] + C_parts2 * P_parts_defect2[i]
        p2 = 0  # 检测后无次品
    else:
        p2 = P_parts_defect2[i]

    # 成品次品率计算
    if xp1 == 1 and xp2 == 1:
        final_defect = P_final_defect[i]
    elif xp1 == 0 and xp2 == 0:
        P_not_checked = 1 - (1 - p1) * (1 - p2)
        final_defect = P_not_checked + (1 - P_not_checked) * P_final_defect[i]
    else:
        P_not_checked = p1 if xp1 == 0 else p2
        final_defect = P_not_checked + (1 - P_not_checked) * P_final_defect[i]

    # 装配成本
    cost_assemble = C_assemble

    # 成品检测成本
    if xf == 1:
        cost_final = D_final[i]
        cost_replace = 0  # 成品检测后不需要调换
    else:
        cost_final = 0  # 未检测时没有检测成本
        cost_replace = L_replace[i] * final_defect  # 未检测成品的调换损失

    # 计算拆解收益
    disassemble_profit = 0
    if xp1:
        disassemble_profit += C_parts1
    else:
        disassemble_profit += (p2 * (1 - p1) + P_final_defect[i] * (1 - p1) * (1 - p2)) / final_defect * C_parts1

    if xp2:
        disassemble_profit += C_parts2
    else:
        disassemble_profit += (p1 * (1 - p2) + P_final_defect[i] * (1 - p1) * (1 - p2)) / final_defect * C_parts2

    # 判断是否拆解成品
    if xd == 1 and disassemble_profit > D_disassemble[i]:
        cost_disassemble = (D_disassemble[i] - disassemble_profit) * final_defect
    else:
        cost_disassemble = 0

    # 计算总成本（固定成本 + 可变成本）
    total_cost = cost_parts + cost_assemble + cost_final + cost_replace + cost_disassemble

    # 计算利润：总收入减去总成本
    total_income = Market_price * (1 - final_defect)  # 售卖的合格成品的收入
    profit = total_income - total_cost  # 利润

    return total_cost, profit

delta = 0.1
while delta >= 0.0000001:
    # 遍历每种情形，将零件1的置信区间等分为400份，并使用区间中点作为次品率
    detection_results = []
    for i, (lower_bound, upper_bound) in enumerate(confidence_intervals_parts1):
        step_size = delta
        samples = np.array([lower_bound + j * step_size for j in range(int((upper_bound - lower_bound) / delta))])

        # 初始化检测次数统计
        detection_count_1 = 0  # 零件1
        detection_count_2 = 0  # 零件2
        detection_count_f = 0  # 成品
        detection_count_d = 0  # 成品拆解

        # 遍历所有可能的次品率
        for sample in samples:
            # 枚举所有检测和拆解组合，并选择利润最大的一种
            max_profit = -np.inf
            best_solution = None

            for xp1 in range(2):  # 零件1是否检测
                for xp2 in range(2):  # 零件2是否检测
                    for xf in range(2):  # 成品是否检测
                        for xd in range(2):  # 成品是否拆解
                            total_cost, profit = calculate_cost_and_profit([xp1, xp2, xf, xd], i, sample)
                            if profit > max_profit:
                                max_profit = profit
                                best_solution = [xp1, xp2, xf, xd]

            # 统计检测和拆解次数
            if best_solution[0] == 1:
                detection_count_1 += 1
            if best_solution[1] == 1:
                detection_count_2 += 1
            if best_solution[2] == 1:
                detection_count_f += 1
            if best_solution[3] == 1:
                detection_count_d += 1

        # 将统计结果添加到结果列表中
        detection_results.append([detection_count_1, detection_count_2, detection_count_f, detection_count_d])

    # 将检测结果写入CSV文件
    csv_file = f"data_parts1_{delta}.csv"
    with open(csv_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['circumstance', 'part1', 'part2', 'final_product', 'disassemble'])
        for i, result in enumerate(detection_results):
            writer.writerow([f'circumstance {i + 1}', result[0], result[1], result[2], result[3]])

    # 输出完成信息
    print(f"检测结果已保存到 {csv_file}")
    delta /= 10
