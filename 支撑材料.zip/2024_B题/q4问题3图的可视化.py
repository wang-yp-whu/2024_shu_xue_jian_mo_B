import matplotlib.pyplot as plt
import numpy as np
from matplotlib.font_manager import FontProperties

# 加载SimHei字体
myfont = FontProperties(fname='/Users/panlongxiang/Documents/数模/2024_B题/SimHei.ttf')

# 决策数据统计结果，包含所有部件的决策数据（根据您的数据添加完整内容）
results = {
    "部件 1": [
        "0000000011100001", "0000000011110101", "0000000011111101", 
        "0000000011100101", "0000000011101101", "0000000011101001", 
        "0000000011110001", "0000000011111001", "1000000011111101", 
        "0001000011100001", "1000000011110101", "0001001011110101", 
        "0000000011111100"
    ],
    "部件 2": [
        "0000000011101001", "0000000011111101", "0000000011110001", 
        "0000000011101101", "0000000011100001", "0000000011110101", 
        "0000000011111001", "0000000011100101", "0001000011111101", 
        "1000000011101101", "0001000011101101"
    ],
    "部件 3": [
        "0000000011110101", "0000000011111101", "0000000011100001", 
        "0000000011110001", "0000000011100101", "0000000011101101", 
        "0000000011111001", "0000000011101001", "0001000011100101", 
        "1000000011100001", "0000100011100101", "0001000011101101", 
        "0001000011111001"
    ],
    # 添加部件 4 到部件 12 的决策数据...
}

# 出现次数，按部件分别列出
frequency = {
    "部件 1": [36, 35, 29, 29, 27, 25, 24, 24, 1, 1, 1, 1],
    "部件 2": [36, 34, 33, 31, 30, 27, 22, 18, 1, 1, 1],
    "部件 3": [36, 36, 32, 32, 27, 24, 23, 16, 3, 2, 1, 1, 1],
    # 添加部件 4 到部件 12 的出现次数...
}

# 计算每个位的0和1的比重
def calculate_bit_ratios(results, frequencies):
    ratios = np.zeros((16, 2))  # 每个位的0和1的比例
    total_count = sum(frequencies)  # 总的决策次数
    
    for decision, freq in zip(results, frequencies):
        for i, bit in enumerate(decision):
            if bit == "0":
                ratios[i, 0] += freq  # 统计0的次数
            else:
                ratios[i, 1] += freq  # 统计1的次数
    
    # 计算比例
    ratios = ratios / total_count
    return ratios

# 绘制柱状图函数
def plot_bit_ratios(part_name, ratios):
    fig, ax = plt.subplots(figsize=(10, 6))
    indices = np.arange(1, 17)  # 决策位从1到16
    
    # 绘制每个位的0和1比重
    ax.bar(indices - 0.2, ratios[:, 0], width=0.4, label='比重0', color='blue')
    ax.bar(indices + 0.2, ratios[:, 1], width=0.4, label='比重1', color='orange')
    
    # 设置标题和标签，并加载中文字体
    ax.set_xlabel("决策位", fontsize=14, fontproperties=myfont)
    ax.set_ylabel("比重", fontsize=14, fontproperties=myfont)
    ax.set_title(f"{part_name} 各决策位0和1的比重", fontsize=16, fontproperties=myfont)
    
    # 添加图例
    ax.legend(prop=myfont)
    
    # 设置x轴刻度
    ax.set_xticks(indices)
    ax.set_xticklabels([f"位{i}" for i in range(1, 17)], fontproperties=myfont)
    
    # 显示图表
    plt.tight_layout()
    plt.savefig(f"part{part_name}变化决策位占比图.png")
    plt.show()

# 遍历每个部件，生成其决策比重的柱状图
for part_name, decisions in results.items():
    frequencies = frequency[part_name]  # 对应的出现次数
    ratios = calculate_bit_ratios(decisions, frequencies)  # 计算每个位的比重
    plot_bit_ratios(part_name, ratios)  # 绘制柱状图
