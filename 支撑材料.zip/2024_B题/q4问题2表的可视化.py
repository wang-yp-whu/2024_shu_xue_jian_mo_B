import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager

# 设置中文字体
font_path = '/Users/panlongxiang/Documents/数模/2024_B题/SimHei.ttf'  # 请根据您的环境修改字体路径
my_font = font_manager.FontProperties(fname=font_path)

# 定义情形的数据
data = {
    "情形 1": np.array([[0.93, 1.00, 1.00],
                        [1.00, 0.72, 1.00],
                        [0.00, 0.00, 0.00],
                        [1.00, 1.00, 1.00]]),
    "情形 2": np.array([[1.00, 1.00, 1.00],
                        [1.00, 1.00, 1.00],
                        [0.00, 0.00, 0.00],
                        [1.00, 1.00, 1.00]]),
    "情形 3": np.array([[0.865, 1.00, 1.00],
                        [1.00, 0.6225, 1.00],
                        [0.135, 0.3775, 0.50],
                        [1.00, 1.00, 1.00]]),
    "情形 4": np.array([[1.00, 1.00, 1.00],
                        [1.00, 1.00, 1.00],
                        [1.00, 1.00, 1.00],
                        [1.00, 1.00, 1.00]]),
    "情形 5": np.array([[0.00, 0.00, 0.00],
                        [1.00, 1.00, 1.00],
                        [0.405, 0.00, 0.405],
                        [1.00, 1.00, 1.00]]),
    "情形 6": np.array([[0.6525, 1.00, 1.00],
                        [0.00, 0.315, 0.00],
                        [0.00, 0.00, 0.00],
                        [0.00, 0.00, 0.00]])
}

# 定义列标签和行标签
columns = ["零件1", "零件2", "成品"]
rows = ["决策位1", "决策位2", "决策位3", "决策位4"]

# 创建热力图
def plot_heatmap(data, title, ax):
    cax = ax.matshow(data, cmap='coolwarm', vmin=0, vmax=1)
    ax.set_xticks(np.arange(len(columns)))
    ax.set_xticklabels(columns, fontproperties=my_font)
    ax.set_yticks(np.arange(len(rows)))
    ax.set_yticklabels(rows, fontproperties=my_font)
    ax.set_title(title, fontproperties=my_font, pad=20)
    
    # 添加横线分隔决策位
    for j in range(1, len(rows)):
        ax.hlines(j - 0.5, xmin=-0.5, xmax=len(columns) - 0.5, colors='black', linewidth=2)

    # 添加颜色条
    plt.colorbar(cax, ax=ax)

# 创建子图
fig, axes = plt.subplots(2, 3, figsize=(18, 12))
axes = axes.flatten()

# 遍历情形并绘制热力图
for i, (title, data_matrix) in enumerate(data.items()):
    plot_heatmap(data_matrix, title, axes[i])

# 调整布局
plt.tight_layout()
plt.savefig("问题4第二问热力图_带横线.png")
plt.show()
