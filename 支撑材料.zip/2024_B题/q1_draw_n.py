import numpy as np
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

# Define constants
z_alpha1 = 1.645  # 情形1
z_alpha2 = 1.28   # 情形2
p_0 = 0.10

# Define delta values
delta_values = np.linspace(0.01, 0.1, 100)

# Calculate n for each delta for both z_alpha1 and z_alpha2
n_values_1 = (z_alpha1**2 * p_0 * (1 - p_0)) / delta_values**2
n_values_2 = (z_alpha2**2 * p_0 * (1 - p_0)) / delta_values**2

# Recalculate n for delta = 0.05 and delta = 0.1
delta_05 = 0.05
delta_10 = 0.1
n_05_1 = (z_alpha1**2 * p_0 * (1 - p_0)) / delta_05**2
n_10_1 = (z_alpha1**2 * p_0 * (1 - p_0)) / delta_10**2
n_05_2 = (z_alpha2**2 * p_0 * (1 - p_0)) / delta_05**2
n_10_2 = (z_alpha2**2 * p_0 * (1 - p_0)) / delta_10**2

# Load SimHei font
myfont = FontProperties(fname='/Users/panlongxiang/Documents/数模/2024_B题/SimHei.ttf')

# Plotting delta vs n
plt.figure(figsize=(8, 6))

# Plot for z_alpha1
plt.plot(delta_values, n_values_1, label=r'情形（1）平均样本量曲线', color='b')
# Marking delta = 0.05 and delta = 0.1 for z_alpha1
plt.scatter([delta_05, delta_10], [n_05_1, n_10_1], color='b')  # points
plt.text(delta_05, n_05_1 + 500, f'n={n_05_1:.2f}', fontsize=12, ha='left', va='bottom', color='b')
plt.text(delta_10, n_10_1 + 500, f'n={n_10_1:.2f}', fontsize=12, ha='left', va='bottom', color='b')

# Plot for z_alpha2
plt.plot(delta_values, n_values_2, label=r'情形（2）平均样本量曲线', color='r')
# Marking delta = 0.05 and delta = 0.1 for z_alpha2
plt.scatter([delta_05, delta_10], [n_05_2, n_10_2], color='r')  # points
plt.text(delta_05, n_05_2 - 500, f'n={n_05_2:.2f}', fontsize=12, ha='left', va='top', color='r')
plt.text(delta_10, n_10_2 - 500, f'n={n_10_2:.2f}', fontsize=12, ha='left', va='top', color='r')

# Plot configurations with SimHei font
plt.xlabel(r'偏差（真实次品率-标称值）', fontsize=14, fontproperties=myfont)
plt.ylabel('平均样本量', fontsize=14, fontproperties=myfont)
plt.title(r'平均样本量（ASN曲线）', fontsize=16, fontproperties=myfont)
plt.grid(True)
plt.legend(prop=myfont)
plt.tight_layout()
plt.show()
