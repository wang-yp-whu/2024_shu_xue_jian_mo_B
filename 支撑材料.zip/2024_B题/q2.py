import numpy as np

# 定义参数
P_parts_defect1 = [0.1, 0.2, 0.1, 0.2, 0.1, 0.05]  # 零配件 1 的次品率
P_parts_defect2 = [0.1, 0.2, 0.1, 0.2, 0.2, 0.05]  # 零配件 2 的次品率
P_final_defect = [0.1, 0.2, 0.1, 0.2, 0.1, 0.05]   # 成品的次品率

C_parts1 = 4  # 零配件 1 的购买成本
C_parts2 = 18  # 零配件 2 的购买成本
D_parts1 = [2, 2, 2, 1, 8, 2]  # 零配件 1 的检测成本
D_parts2 = [3, 3, 3, 1, 1, 3]  # 零配件 2 的检测成本
C_assemble = 6  # 装配成本
D_final = [3, 3, 3, 2, 2, 3]  # 成品的检测成本
Market_price = 56  # 市场售价
L_replace = [6, 6, 30, 30, 10, 10]  # 调换损失
D_disassemble = [5, 5, 5, 5, 5, 40]  # 拆解费用

# 初始化最优结果
optimal_decision = np.zeros((6, 4), dtype=int)
max_profit = np.full(6, -np.inf)  # 用于存储最大利润
min_cost = np.full(6, np.inf)     # 用于存储最小成本（对应最大利润的方案）
xd = 0
# 成本和利润计算函数
def calculate_cost_and_profit(solution, i):
    xp1, xp2, xf, tmp1 = solution
    global xd
    # 零配件购买成本始终存在，无论是否销售
    cost_parts = C_parts1 + C_parts2
    
    # 如果对零配件进行检测，加入检测成本
    if xp1 == 1:
        cost_parts += D_parts1[i] + C_parts1 * P_parts_defect1[i]
        p1 = 0  # 检测后无次品
    else:
        p1 = P_parts_defect1[i]

    if xp2 == 1:
        cost_parts += D_parts2[i] + C_parts2 * P_parts_defect2[i]
        p2 = 0  # 检测后无次品
    else:
        p2 = P_parts_defect2[i]
    
    # 成品次品率计算
    if xp1 == 1 and xp2 == 1:
        final_defect = P_final_defect[i]
    elif xp1 == 0 and xp2 == 0:
        P_not_checked = 1 - (1 - p1) * (1 - p2)
        final_defect = P_not_checked + (1 - P_not_checked) * P_final_defect[i]
    else:
        P_not_checked = p1 if xp1 == 0 else p2
        final_defect = P_not_checked + (1 - P_not_checked) * P_final_defect[i]

    # 装配成本
    cost_assemble = C_assemble
    
    # 成品检测成本
    if xf == 1:
        cost_final = D_final[i]
        cost_replace = 0  # 成品检测后不需要调换
    else:
        cost_final = 0  # 未检测时没有检测成本
        cost_replace = L_replace[i] * final_defect  # 未检测成品的调换损失
    
    # 拆解与否只关注带来的效益，同时要乘以次品率，因为只有次品才需要拆解,条件概率问题
    dis_profit = 0
    if xp1:
        dis_profit += C_parts1
    else:
        dis_profit += (p2 * (1-p1) + P_final_defect[i] * (1-p1) * (1-p2)) / final_defect * C_parts1

    if xp2:
        dis_profit += C_parts2
    else:
        dis_profit += (p1 * (1-p2) + P_final_defect[i] * (1-p1) * (1-p2))/ final_defect * C_parts2

    if dis_profit > D_disassemble[i]:
        cost_disassemble = (D_disassemble[i] - dis_profit) * final_defect
        xd = 1
    else:
        cost_disassemble = 0
        xd = 0

    # 计算总成本（固定成本 + 可变成本）
    total_cost = cost_parts + cost_assemble + cost_final + cost_replace + cost_disassemble
    
    # 计算利润：总收入减去总成本
    total_income = Market_price * (1 - final_defect)  # 售卖的合格成品的收入
    profit = total_income - total_cost  # 利润
    
    return total_cost, profit

# 遍历每种情形，寻找最大利润方案
for i in range(6):
    dp = np.full((2, 2, 2, 2), -np.inf)  # 更新为利润最大化

    # 初始化每个状态的利润
    for xp1 in range(2):
        for xp2 in range(2):
            for xf in range(2):
                total_cost, profit = calculate_cost_and_profit([xp1, xp2, xf, xd], i)
                dp[xp1, xp2, xf, xd] = profit
                
                # 更新最大利润并记录对应的成本
                if profit > max_profit[i]:
                    max_profit[i] = profit
                    min_cost[i] = total_cost  # 对应最大利润的成本
    
    # 寻找最大利润对应的决策方案
    optimal_index = np.unravel_index(np.argmax(dp), dp.shape)
    optimal_decision[i, :] = np.array(optimal_index)

# 输出结果
for i in range(6):
    print(f'情形 {i+1} 的最优决策方案:')
    print(f'零配件1检测: {optimal_decision[i, 0]}')
    print(f'零配件2检测: {optimal_decision[i, 1]}')
    print(f'成品检测: {optimal_decision[i, 2]}')
    print(f'不合格成品拆解: {optimal_decision[i, 3]}')
    print(f'最大利润: {max_profit[i]:.2f} 元')
    print(f'对应的最小成本: {min_cost[i]:.2f} 元\n')

